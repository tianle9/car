package com.atguigu.sys.service;

import com.atguigu.sys.vo.UserVo;

public interface UserRoleService {
    void saveUserRole(UserVo userVo);
}
